# 106232052310523-1

## Extensions in VS Editor

1. Live Server
2. Prettier - code formatter
3. Auto close tag
4. Auto Rename Tag

## Prettier VS Code:

https://www.digitalocean.com/community/tutorials/how-to-format-code-with-prettier-in-visual-studio-code

### Terminal => ctrl + shift + `

### BEM

Block Element Modifier
https://getbem.com/

full_name
full__name
full___name

full-name
full--name
full---name

https://fontawesome.com/
https://cdnjs.com/libraries/font-awesome

https://fonts.google.com/
https://fonts.google.com/specimen/Poppins


https://cssgradient.io/
